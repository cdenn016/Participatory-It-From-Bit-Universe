# -*- coding: utf-8 -*-
"""
Created on Sat Nov  8 20:57:25 2025

@author: chris and christine
"""

